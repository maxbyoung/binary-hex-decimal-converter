All of my code is in Operations.java, all of my printing is done in main along
with task one and task two. All of my conversions, both complements, the and, or,
xor methods, and the shifts all have methods outside of main. I have some extra helper 
methods and also the checking methods are also not in main. Sorry if the structure is
a little jumbled and I appreciate your time!

Also Dan said that it was okay to use .toString when converting back from integer to string

Thanks!