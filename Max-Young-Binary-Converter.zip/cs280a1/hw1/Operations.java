package cs280a1.hw1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Operations {

    public static boolean checkBinary(String num) {
        if (num.length() > 1 && num.charAt(1) != 'b') {
            return false;
        }
        if (num.length() < 3 && num.length() > 1 && num.charAt(1) == 'b') {
            return false;
        }
        for (char ch : num.toCharArray()) {
            if (ch != '1' && ch != '0' && ch != 'b') {
                return false;
            }
        }
        return true;
    }

    public static boolean checkHex(String num) {
        if (num.length() > 1 && num.charAt(1) != 'x') {
            return false;
        }
        if (num.length() < 3 && num.length() > 1 && num.charAt(1) == 'x') {
            return false;
        }
        for (char ch : num.toCharArray()) {
            boolean letterRange = (ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f');
            boolean numRange = ch >= '0' && ch <= '9';
            boolean descriptCheck = (ch == 'x' || ch == 'X');
            if (!((letterRange || numRange) || descriptCheck)) {
                return false;
            }
        }
        return true;
    }

    public static boolean checkDecimal(String num) {
        for (char ch : num.toCharArray()) {
            if (!Character.isDigit(ch)) {
                return false;
            }
        }
        return true;
    }

    public static ArrayList<Integer> createBList(String num) {
        ArrayList<Integer> bList = new ArrayList<>();
        int highestNum = (int) Math.pow(2, num.length() -1);
        for (int i = highestNum; i >= 1; i /= 2) {
           bList.add(i);
        }
        return bList;
    }

    public static String convertBinaryToDecimal(String num) {
        ArrayList<Integer> bList = createBList(num);
        int binaryAdder = 0;
        for (int i = 0; i < num.length(); i++) {
            if (num.charAt(i) == '1') {
                binaryAdder += bList.get(i);
            }
        }
        return Integer.toString(binaryAdder);
        //Dan said toString() was okay to use.
    }

    public static String convertBinaryToHex(String num) {
        ArrayList<String> convBytes = new ArrayList<>();
        String byteHexVals = "";
        if (num.contains("0b")) {
            num = num.substring(2);
        }
        while (num.length() % 4 != 0) {
            num = "0" + num;
        }
        while (num.length() >= 4) {
            String pasNum = num.substring(0, 4);
            convBytes.add(convertBinaryToDecimal(pasNum));
            num = num.substring(4);
        }
        for(String byt : convBytes) {
            if (byt.length() > 1) {
                switch(byt) {
                    case "10":
                        byteHexVals += "a";
                        break;
                    case "11":
                        byteHexVals += "b";
                        break;
                    case "12":
                        byteHexVals += "c";
                        break;
                    case "13":
                        byteHexVals += "d";
                        break;
                    case "14":
                        byteHexVals += "e";
                        break;
                    case "15":
                        byteHexVals += "f";
                        break;
                }
            }
            else {
                byteHexVals += byt;
            }
        }
        return byteHexVals;
    }

    public static int convertStringToInt(String num) {
        int intVal = 0;
        int j = 0;
        for (int i = num.length() - 1; i >= 0; i--) {
            intVal += ((int) Math.pow(10, i)) * (num.charAt(j) - '0');
            j++;
        }
        return intVal;
    }

    public static String convertDecimalToBinary(String num) {
        String bString = "";
        int intNum = convertStringToInt(num);
        if (num.equals("0")) {
            return "0";
        }
        while (intNum > 0) {
            bString = (intNum % 2) + bString;
            intNum /= 2;
        }
        return bString;
    }

    public static String convertDecimalToHex(String num) {
        return convertBinaryToHex(convertDecimalToBinary(num));
    }

    public static String digitHelper(String digit) {
        String convDigit = convertDecimalToBinary(digit);
        while (convDigit.length() < 4) {
            convDigit = '0' + convDigit;
        }
        return convDigit;
    }

    public static String charHelper(char ch) {
        ch = Character.toLowerCase(ch);
        switch(ch) {
            case 'a':
                return digitHelper("10");
            case 'b':
                return digitHelper("11");
            case 'c':
                return digitHelper("12");
            case 'd':
                return digitHelper("13");
            case 'e':
                return digitHelper("14");
            case 'f':
                return digitHelper("15");
            default:
                return "Error: not a char";
        }
    }

    public static String convertHexToBinary(String num) {
        String binAdder = "";
        for (char ch : num.toCharArray()) {
            if (Character.isDigit(ch)) {
                binAdder += digitHelper(Character.toString(ch));
            }
            else {
                binAdder += charHelper(ch);
            }
        }
        return binAdder;
    }

    public static String convertHexToDecimal(String num) {
        return convertBinaryToDecimal(convertHexToBinary(num));
    }

    public static String removeLeadZeros(String num) {
        if (convertStringToInt(num) == 0) {
            return "0";
        }
        while (!num.isEmpty() && num.charAt(0) == '0') {
            num = num.substring(1);
        }
        return num;
    }

    public static String onesCompConvert(String num) {
        String compAdder = "";
        for (char ch : num.toCharArray()) {
            if (ch == '1') {
                compAdder += '0';
            }
            else {
                compAdder += '1';
            }
        }
        return compAdder;
    }

    public static String twosCompConvert(String num) {
        String onesComp = onesCompConvert(num);
        String decimalString = convertBinaryToDecimal(onesComp);
        int twosDecimalInt = convertStringToInt(decimalString) + 1;
        String twosDecimalString = Integer.toString(twosDecimalInt);
        String binaryResult = convertDecimalToBinary(twosDecimalString);

        while (binaryResult.length() < num.length()) {
            binaryResult = "0" + binaryResult;
        }
        return binaryResult;
    }

    public static String bitOr(String bNum, String dNum, String hNum) {
        return orHelper(orHelper(bNum, dNum), hNum);
    }

    public static String orHelper(String num1, String num2) {
        String adder = "";
        while (num1.length() < num2.length()) {
            num1 = "0" + num1; 
        }
        while (num2.length() < num1.length()) {
            num2 = "0" + num2;
        }
        for (int i = 0; i < num1.length(); i++) {
            if (num1.charAt(i) == '1' || num2.charAt(i) == '1') {
                adder += "1";
            }
            else {
                adder += "0";
            }
        }
        return adder;
    }

    public static String bitAnd(String bNum, String dNum, String hNum) {
        return andHelper(andHelper(bNum, dNum), hNum);
    }

    public static String andHelper(String num1, String num2) {
        String adder = "";
        while (num1.length() < num2.length()) {
            num1 = "0" + num1; 
        }
        while (num2.length() < num1.length()) {
            num2 = "0" + num2;
        }
        for (int i = 0; i < num1.length(); i++) {
            if (num1.charAt(i) == '1' && num2.charAt(i) == '1') {
                adder += "1";
            }
            else {
                adder += "0";
            }
        }
        return adder;
    }

    public static String bitXor(String bNum, String dNum, String hNum) {
        return xorHelper(xorHelper(bNum, dNum), hNum);
    }

    public static String xorHelper(String num1, String num2) {
        String adder = "";
        while (num1.length() < num2.length()) {
            num1 = "0" + num1; 
        }
        while (num2.length() < num1.length()) {
            num2 = "0" + num2;
        }
        for (int i = 0; i < num1.length(); i++) {
            if (num1.charAt(i) == '1' && num2.charAt(i) == '1') {
                adder += "0";
            }
            else if (num1.charAt(i) == '1' || num2.charAt(i) == '1') {
                adder += "1";
            }
            else {
                adder += "0";
            }
        }
        return adder;
    }

    public static String leftShift(String num) {
        return num + "00";
    }

    public static String rightShift(String num) {
        if (num.length() > 1) {
            return num.substring(0, num.length() - 2);
        }
        return "";
    }

    public static void main(String[] args) {
        String bNum = "E";
        String hNum = "E";
        String dNum = "E";

        //Task 1
        System.out.println("Task 1");
        if (args.length != 3) {
            System.out.println("Incorrect number of arguments "
            + "have been provided. Program Terminating!");
            System.exit(0);
        }
        else {
            System.out.println("Correct number of arguments given.\n");
        }

        //Task 2
        System.out.println("Task 2");
        for (String arg : args) {
            //binary
            if (arg.length() > 1 && arg.charAt(1) == 'b') {
                System.out.println(arg + "=Binary");
                bNum = arg;
            }
            //Hexadecimal
            else if (arg.length() > 1 && arg.charAt(1) == 'x') {
                System.out.println(arg + "=Hexadecimal");
                hNum = arg;
            }
            //Decimal
            else {
                System.out.println(arg + "=Decimal");
                dNum = arg;
            }
        }
        System.out.println();

        //Task 3
        System.out.println("Task 3");
        boolean exit = false;
        for (String arg: args) {
            if (checkBinary(arg) || checkHex(arg) || checkDecimal(arg)) {
                System.out.println(arg + "=true");
            }
            else {
                System.out.println(arg + "=false");
                exit = true;
            }
        }
        if (exit) {
            System.out.println("Error: invalid characters or none provided");
            System.exit(0);
        }
        System.out.println();

        //Task 4
        System.out.println("Task 4");
        
        String bSub = bNum.substring(2);
        String hSub = hNum.substring(2);

        String BDConv = removeLeadZeros(convertBinaryToDecimal(bSub));
        String BHConv = removeLeadZeros(convertBinaryToHex(bNum));
        String DBConv = removeLeadZeros(convertDecimalToBinary(dNum));
        String DHConv = removeLeadZeros(convertDecimalToHex(dNum));
        String HBConv = removeLeadZeros(convertHexToBinary(hSub));
        String HDConv = removeLeadZeros(convertHexToDecimal(hSub));

        for (String arg : args) {
            //binary
            if (arg.length() > 1 && arg.charAt(1) == 'b') {
                System.out.printf("Start=%s,Binary=%s,Decimal=%s,Hexadecimal=0x%s\n", bNum, bNum, BDConv, BHConv);
            }
            //Hexadecimal
            else if (arg.length() > 1 && arg.charAt(1) == 'x') {
                System.out.printf("Start=%s,Binary=0b%s,Decimal=%s,Hexadecimal=%s\n", hNum, HBConv, HDConv, hNum);
            }
            //Decimal
            else {
                System.out.printf("Start=%s,Binary=0b%s,Decimal=%s,Hexadecimal=0x%s\n", dNum, DBConv, dNum, DHConv);
            }
        }
        System.out.println();
        
        //Task 5
        System.out.println("Task 5");

        for (String arg : args) {
            if (arg.length() > 1 && arg.charAt(1) == 'b') {
                System.out.printf("%s=%s=>%s\n", bNum, bSub, onesCompConvert(bSub));
            }
            //Hexadecimal
            else if (arg.length() > 1 && arg.charAt(1) == 'x') {
                System.out.printf("%s=%s=>%s\n", hNum, HBConv, onesCompConvert(HBConv));
            }
            //Decimal
            else {
                System.out.printf("%s=%s=>%s\n", dNum, DBConv, onesCompConvert(DBConv));
            }
        }
        System.out.println();

        //Task 6
        System.out.println("Task 6");

        for (String arg : args) {
            //Binary
            if (arg.length() > 1 && arg.charAt(1) == 'b') {
                System.out.printf("%s=%s=>%s\n", bNum, bSub, twosCompConvert(bSub));
            }
            //Hexadecimal
            else if (arg.length() > 1 && arg.charAt(1) == 'x') {
                System.out.printf("%s=%s=>%s\n", hNum, HBConv, twosCompConvert(HBConv));
            }
            //Decimal
            else {
                System.out.printf("%s=%s=>%s\n", dNum, DBConv, twosCompConvert(DBConv));
            }
        }
        System.out.println();

        //Task 7
        System.out.println("Task 7");

        Queue<String> argsList = new LinkedList<>();

        for (String arg: args) {
            if (!(arg.length() > 1 && arg.charAt(1) == 'b')) {
                if (arg.length() > 1 && arg.charAt(1) == 'x') {
                    argsList.add(removeLeadZeros(convertHexToBinary(arg.substring(2))));
                }
                else {
                    argsList.add(removeLeadZeros(convertDecimalToBinary(arg)));
                }
            }
            else {
                argsList.add(arg.substring(2));
            }
        }

        String first = argsList.poll();
        String second = argsList.poll();
        String third = argsList.poll();

        System.out.printf("%s|%s|%s=%s\n", first, second, third, bitOr(first, second, third));
        System.out.printf("%s&%s&%s=%s\n", first, second, third, bitAnd(first, second, third));
        System.out.printf("%s^%s^%s=%s\n", first, second, third, bitXor(first, second, third));
        System.out.println();

        //Task 8
        System.out.println("Task 8");

        for (String arg : args) {
            //Binary
            if (arg.length() > 1 && arg.charAt(1) == 'b') {
                System.out.printf("%s<<2=%s,%s>>2=%s\n", bSub, leftShift(bSub), bSub, rightShift(bSub));
            }
            //Hexadecimal
            else if (arg.length() > 1 && arg.charAt(1) == 'x') {
                System.out.printf("%s<<2=%s,%s>>2=%s\n", HBConv, leftShift(HBConv), HBConv, rightShift(HBConv));
            }
            //Decimal
            else {
                System.out.printf("%s<<2=%s,%s>>2=%s\n", DBConv, leftShift(DBConv), DBConv, rightShift(DBConv));
            }
        }
        System.out.println();
    }
}